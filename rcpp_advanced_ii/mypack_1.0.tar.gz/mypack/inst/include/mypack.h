#ifndef RCPP_mypack_H_GEN_
#define RCPP_mypack_H_GEN_

#include "mypack_RcppExports.h"

#include "smart/smart.h"

#endif
