#ifndef smart_library
#define smart_library

namespace smart{

  inline double mysquare(double x){
    return x * x;
  }

}

#endif
